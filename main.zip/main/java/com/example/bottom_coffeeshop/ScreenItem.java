package com.example.bottom_coffeeshop;

public class ScreenItem {

    int ScreenImg;

    public ScreenItem( int screenImg) {
        ScreenImg = screenImg;
    }

    public void setScreenImg(int screenImg) {
        ScreenImg = screenImg;
    }

    public int getScreenImg() {
        return ScreenImg;
    }
}
