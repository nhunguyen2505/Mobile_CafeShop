package com.example.bottom_coffeeshop;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;

public class ProfileFragment extends Fragment {
    Button btnChange;
    public static TextView tvUsername, tvEmail, tvPhone, tvAddress, tvUsernameCardView;
    private String username, password;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_profile_tview, container, false);

        MainActivity mainActivity=(MainActivity) getActivity();
        username=mainActivity.getUsername();
        password=mainActivity.getPassword();

                tvEmail=(TextView) view.findViewById(R.id.txtEmail);
        tvUsername=(TextView) view.findViewById(R.id.txtUsername);
        tvPhone=(TextView) view.findViewById(R.id.txtPhone);
        tvAddress=(TextView) view.findViewById(R.id.txtAddress);
        tvUsernameCardView=(TextView) view.findViewById(R.id.tvUsernameCardView1);

        FirebaseDatabase database=FirebaseDatabase.getInstance();
        final DatabaseReference databaseUser=database.getReference("Users");

        databaseUser.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    User user=dataSnapshot.child(username).getValue(User.class);
                    /*setUser(user);*/
                    tvUsernameCardView.setText(username);
                    tvUsername.setText(username);
                    tvEmail.setText(user.getEmail());
                    tvPhone.setText(user.getPhone());
                    tvAddress.setText(user.getAddress());

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w(String.valueOf(ProfileFragment.this), "loadPost:onCancelled", databaseError.toException());

            }
        });

        btnChange=(Button) view.findViewById(R.id.btnChange);
        btnChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(), ProfileChange.class);
                intent.putExtra("username", username);
                intent.putExtra("password", password);
                startActivityForResult(intent, 1);
            }
        });
        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
               /* tvUsernameCardView.setText(data.getStringExtra("username"));
                tvUsername.setText(data.getStringExtra("username"));
                tvAddress.setText(data.getStringExtra("address"));
                tvEmail.setText(data.getStringExtra("email"));
                tvPhone.setText(data.getStringExtra("phone"));*/
                Toast.makeText(getContext(), "Data has been saved", Toast.LENGTH_SHORT).show();

            }
            if (resultCode == RESULT_CANCELED) {
                Toast.makeText(getContext(), "Cant receive date", Toast.LENGTH_SHORT).show();
            }
        }
    }


}
