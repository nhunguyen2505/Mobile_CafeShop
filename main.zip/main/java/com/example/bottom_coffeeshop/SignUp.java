package com.example.bottom_coffeeshop;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp extends AppCompatActivity {

    EditText edtPassWord1, edtEmail1, edtPhone1, edtUser1, edtAddress1;
    Button btnSignUp;

    // init FireBase
    DatabaseReference table_user = FirebaseDatabase.getInstance().getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        edtPassWord1 = findViewById(R.id.edtPass1);
        edtEmail1 = findViewById(R.id.edtEmail1);
        edtPhone1 = findViewById(R.id.edtPhone1);
        edtUser1 = findViewById(R.id.edtUsername1);
        edtAddress1 = findViewById(R.id.edtAddress1);
        btnSignUp = findViewById(R.id.btnSignUp1);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = edtEmail1.getText().toString().trim();
                String password = edtPassWord1.getText().toString().trim();
                String phone = edtPhone1.getText().toString().trim();
                String username = edtUser1.getText().toString().trim();
                String address = edtAddress1.getText().toString().trim();

                if(TextUtils.isEmpty(email)){
                    edtEmail1.setError("Email isn't empty");
                }
                else if(TextUtils.isEmpty(password)){
                    edtPassWord1.setError("Password isn't empty");
                }
                else if(password.length() < 6){
                    edtPassWord1.setError("Password must be at least 6 characters");
                }
                else if(TextUtils.isEmpty(phone)){
                    edtPhone1.setError("Phone isn't empty");
                }
                else if(TextUtils.isEmpty(username)){
                    edtUser1.setError("Username isn't empty");
                }
                else if(TextUtils.isEmpty(address)){
                    edtAddress1.setError("Phone isn't empty");
                }
                else {
                    User user = new User();
                    user.setEmail(email);
                    user.setPhone(phone);
                    user.setAddress(address);
                    user.setPassword(password);
                    table_user.child("Users").child(username).setValue(user);

                    Intent intent = new Intent(SignUp.this,SignIn.class);
                    startActivity(intent);
                }
            }
        });
    }
}