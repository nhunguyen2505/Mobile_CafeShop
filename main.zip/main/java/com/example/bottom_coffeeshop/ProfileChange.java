package com.example.bottom_coffeeshop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfileChange extends AppCompatActivity {

    EditText  edtEmail, edtPhone, edtAddress;
    TextView tvUsernameCardView2, tvUsername;
    Button btnSave;
    public static String username, password;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_profile_edtext);

        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        password = intent.getStringExtra("password");

        tvUsernameCardView2=findViewById(R.id.tvUsernameCardView2);
        tvUsername=findViewById(R.id.tvUsernameChange);
        edtAddress=findViewById(R.id.edtAddress);
        edtEmail=findViewById(R.id.edtEmail);
        edtPhone=findViewById(R.id.edtPhone);
        btnSave=findViewById(R.id.btnSave);

        FirebaseDatabase database=FirebaseDatabase.getInstance();
        final DatabaseReference databaseUser=database.getReference("Users");

        databaseUser.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    User user=dataSnapshot.child(username).getValue(User.class);
                    /*setUser(user);*/
                    tvUsernameCardView2.setText(username);
                    tvUsername.setText(username);
                    edtEmail.setText(user.getEmail());
                    edtPhone.setText(user.getPhone());
                    edtAddress.setText(user.getAddress());

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                User user = new User();
                user.setEmail(edtEmail.getText().toString());
                user.setPhone(edtPhone.getText().toString());
                user.setAddress(edtAddress.getText().toString());
                user.setPassword(password);
                databaseUser.child(username).setValue(user);

                Intent intent = new Intent();
                setResult(RESULT_OK,intent);
                finish();

                Toast.makeText(ProfileChange.this,"Data has been saved",
                        Toast.LENGTH_SHORT).show();

            }
        });
    }
}
