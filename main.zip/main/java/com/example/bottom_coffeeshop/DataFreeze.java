package com.example.bottom_coffeeshop;

public class DataFreeze {
    String name;
    String price;
    int img;
    public DataFreeze(){

    }
    public DataFreeze(String name, String price, int img){
        this.name=name;
        this.price=price;
        this.img=img;
    }
    public String getName(){
        return name;
    }
    public void setName(String drinkName){
        this.name=name;
    }
    public String getPrice(){
        return price;
    }
    public void setPrice(String price){
        this.price=price;
    }
    public int getImg(){
        return img;
    }
    public void setImg(int img){
        this.img=img;
    }
}
