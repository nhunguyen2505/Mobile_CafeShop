package com.example.bottom_coffeeshop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdapterPopularDrink extends RecyclerView.Adapter<MyViewHolder> {
    List<DataDrink> drinkList;
    Context context;
    public AdapterPopularDrink(List<DataDrink> drinkList,Context context){
        this.drinkList=drinkList;
        this.context=context;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        /*View v= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.view_popular,viewGroup,false);
        ViewHolder viewHolder=new ViewHolder(v);
        return viewHolder;*/

        Context context = viewGroup.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View itemView =inflater.inflate(R.layout.view_popular,viewGroup,false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.drinkName.setText(drinkList.get(position).getDrinkName());
        holder.price.setText(drinkList.get(position).getPrice());
        holder.imgDrink.setImageResource(drinkList.get(position).getImg());
    }
    @Override
    public int getItemCount(){
        return drinkList.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView drinkname,price;
        public ViewHolder(@NonNull View itemView){
            super(itemView);
            drinkname=itemView.findViewById(R.id.tvName);
            price=itemView.findViewById(R.id.tvPrice);
        }
    }
}
