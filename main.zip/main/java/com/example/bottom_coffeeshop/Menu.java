package com.example.bottom_coffeeshop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Menu extends AppCompatActivity {

    public static ArrayList<MotaThanhtoan> listdanhsach;
    RecyclerView rvPopular,rvPopular1;
    AdapterPopularDrink mApdapter;
    Button btncoffee,btntea,btnfreeze,btncakes;
    String drink[]={"Freeze Chocolate","Cappuccino","Freeze Greentea","Latte","Mocha"};
    String price[]={"49.000","45.000","49.000","45.000","49.000"};
    int image[]={R.drawable.chocolatefreeze1,R.drawable.cappuccino1,R.drawable.greeanteafreeze1,R.drawable.latte1,R.drawable.mocha1};
    AdapterPopularCake mAdapterCake;
    String cake[]={"Tiramisu","Chocolate Mousse","Cheese Greentea"};
    String price1[]={"19.000","29.000","29.000"};
    int image1[]={R.drawable.tiramisu,R.drawable.moussecacao,R.drawable.phomaitraxanh};
    List<DataDrink> dataDrinks = new ArrayList<>();
    ArrayList<DataCake> dataCakes = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);
        rvPopular=findViewById(R.id.rvPopular);
        rvPopular.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,false);
        rvPopular.setLayoutManager(layoutManager);
        rvPopular1=findViewById(R.id.rvPopular1);
        rvPopular1.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager1=new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,false);
        rvPopular1.setLayoutManager(layoutManager1);

        listdanhsach= new ArrayList<MotaThanhtoan>();
        //mapping
        btncoffee=findViewById(R.id.btncoffee);
        btntea=findViewById(R.id.btntea);
        btnfreeze=findViewById(R.id.btnfreeze);
        btncakes=findViewById(R.id.btncakes);

        //set them dividermanager
        DividerItemDecoration decoration = new DividerItemDecoration(this, DividerItemDecoration.HORIZONTAL);
        rvPopular.addItemDecoration(decoration);
        dataDrinks = getDataDrink();
        mApdapter=new AdapterPopularDrink(dataDrinks,this);
        rvPopular.setAdapter(mApdapter);
        rvPopular1.addItemDecoration(decoration);
        dataCakes = getDataCake();
        mAdapterCake=new AdapterPopularCake(dataCakes,this);
        rvPopular1.setAdapter(mAdapterCake);
        btncoffee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(Menu.this,ActivityDrink.class);
                startActivity(intent1);
            }
        });
        btncakes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu.this,ActiviyCake.class);
                //put dữ liệu
                startActivity(intent);
            }
        });
        btnfreeze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu.this,ActivityFreeze.class);
                //put dữ liệu
                startActivity(intent);
            }
        });
        btntea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu.this,ActivityTea.class);
                //put dữ liệu
                startActivity(intent);
            }
        });

    }

    private List<DataDrink> getDataDrink() {
        List<DataDrink> drinkArrayList=new ArrayList<>();

        for(int i=0;i<drink.length;i++){
            DataDrink dataDrink=new DataDrink();
            dataDrink.setDrinkName(drink[i]);
            dataDrink.setPrice(price[i]);
            dataDrink.setImg(image[i]);
            drinkArrayList.add(dataDrink);
        }
        return drinkArrayList;
    }
    private ArrayList<DataCake> getDataCake() {
        ArrayList<DataCake> cakeArrayList=new ArrayList<>();
        for(int i=0;i<cake.length;i++){
            DataCake dataCake=new DataCake();
            dataCake.setCakeName(cake[i]);
            dataCake.setPrice(price1[i]);
            dataCake.setImg(image1[i]);
            cakeArrayList.add(dataCake);
        }
        return cakeArrayList;
    }
}