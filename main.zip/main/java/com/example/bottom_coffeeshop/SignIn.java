package com.example.bottom_coffeeshop;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SignIn extends AppCompatActivity {

    EditText edtUser, edtPassWord;
    Button btnSignIn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        edtUser = findViewById(R.id.edtUser);
        edtPassWord = findViewById(R.id.edtPass);
        btnSignIn = findViewById(R.id.btnLogin);

        // init FireBase
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference table_user = database.getReference("Users");

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = edtUser.getText().toString().trim();
                String password = edtPassWord.getText().toString().trim();

                if(TextUtils.isEmpty(username)){
                    edtUser.setError("Username isn't empty");
                }
                if(TextUtils.isEmpty(password)){
                    edtPassWord.setError("Password isn't empty");
                }

                final ProgressDialog dialog = new ProgressDialog(SignIn.this);
                dialog.setMessage("Please waiting...");
                dialog.show();

                table_user.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        // check if user not exist
                        if(dataSnapshot.child(edtUser.getText().toString()).exists()) {
                            // get user information
                            dialog.dismiss();
                            User user = dataSnapshot.child(edtUser.getText().toString()).getValue(User.class);
                            if (user.getPassword().equals(edtPassWord.getText().toString())) {
                                Toast.makeText(SignIn.this, "Sign in successfully !", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(SignIn.this, MainActivity.class);
                                intent.putExtra("username",edtUser.getText().toString());
                                intent.putExtra("password",edtPassWord.getText().toString());
                                startActivity(intent);
                            } else {
                                Toast.makeText(SignIn.this, "Sign in failed !", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else {
                            Toast.makeText(SignIn.this, "User isn't exist !", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });
    }
}
