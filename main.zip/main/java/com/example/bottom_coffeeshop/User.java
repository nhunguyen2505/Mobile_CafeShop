package com.example.bottom_coffeeshop;

public class User {
    private String Password;
    private String Email;
    private String Phone;
    private String Address;

    public User(){
    }

    public User(String password, String email, String phone, String address) {
        Password = password;
        Email = email;
        Phone = phone;
        Address = address;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        this.Password = password;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        this.Email = email;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        this.Phone = phone;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        this.Address = address;
    }
}
