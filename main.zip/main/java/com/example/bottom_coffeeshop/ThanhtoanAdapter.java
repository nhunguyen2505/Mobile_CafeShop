package com.example.bottom_coffeeshop;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;

public class ThanhtoanAdapter extends BaseAdapter {
    Context context;
    int layout;
    ArrayList<MotaThanhtoan> list;

    public ThanhtoanAdapter(Context context, int layout, ArrayList<MotaThanhtoan> list) {
        this.context = context;
        this.layout = layout;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View view, ViewGroup parent) {

        LayoutInflater inflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view=inflater.inflate(layout,null);
        TextView txtName=view.findViewById(R.id.tvName);
        TextView txtPrice=view.findViewById(R.id.tvPrice);
        ImageView img =view.findViewById(R.id.image);
        final TextView txtsoluong = view.findViewById(R.id.tvsoluong);
        Button btnnGiam = view.findViewById(R.id.btngiam);

        final MotaThanhtoan thanhtoanlist = list.get(position);
        txtName.setText(thanhtoanlist.getTvName());
        txtPrice.setText(thanhtoanlist.getTvPrice());
        img.setImageResource(thanhtoanlist.getImage());
        txtsoluong.setText(thanhtoanlist.getTvsoluong());

        btnnGiam.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1)
            @Override
            public void onClick(View v) {
                int soluong = Integer.parseInt((String) list.get(position).getTvsoluong());
                if(soluong >=2 ){
                    list.get(position).setTvsoluong(String.valueOf(soluong - 1));
                    txtsoluong.setText(thanhtoanlist.getTvsoluong());
                    Thanhtoan.getSum();
                    notifyDataSetChanged();
                }
                else{
                    list.remove(position);
                    Thanhtoan.getSum();
                    notifyDataSetChanged();
                }
            }
        });

        return  view;
    }
}
