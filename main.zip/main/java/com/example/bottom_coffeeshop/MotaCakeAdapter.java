package com.example.bottom_coffeeshop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class MotaCakeAdapter extends BaseAdapter {
    Context context;
    int layout;
    List<MotaListCakes> cakesList;

    public MotaCakeAdapter(Context context, int layout, List<MotaListCakes> cakesList) {
        this.context = context;
        this.layout = layout;
        this.cakesList = cakesList;
    }

    @Override
    public int getCount() {
        return cakesList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        LayoutInflater inflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view=inflater.inflate(layout,null);
        TextView txtName=view.findViewById(R.id.tvName);
        TextView txtPrice=view.findViewById(R.id.tvPricelistcake);
        ImageView img =view.findViewById(R.id.imagelistcake);

        MotaListCakes cakelist = cakesList.get(position);
        txtName.setText(cakelist.getName());
        txtPrice.setText(cakelist.getPrice());
        img.setImageResource(cakelist.getImage());
        return view;
    }
}
