package com.example.bottom_coffeeshop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdapterPopularCake extends RecyclerView.Adapter<MyViewHolder> {
    List<DataCake> cakeList;
    Context context;
    public AdapterPopularCake(List<DataCake> cakeList,Context context){
        this.cakeList=cakeList;
        this.context=context;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        Context context = viewGroup.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View itemView =inflater.inflate(R.layout.view_popular,viewGroup,false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.drinkName.setText(cakeList.get(position).getCakeName());
        holder.price.setText(cakeList.get(position).getPrice());
        holder.imgDrink.setImageResource(cakeList.get(position).getImg());
    }

    @Override
    public int getItemCount(){
        return cakeList.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView cakename,price;
        public ViewHolder(@NonNull View itemView){
            super(itemView);
            cakename=itemView.findViewById(R.id.tvName);
            price=itemView.findViewById(R.id.tvPrice);
        }
    }
}
