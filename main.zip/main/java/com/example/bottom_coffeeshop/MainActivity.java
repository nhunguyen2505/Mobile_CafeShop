package com.example.bottom_coffeeshop;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    //private ProfileFragment mMyFragment;
    String username,password;

    public MainActivity(){}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);

        //Lấy thông tin đăng nhập từ trang sign in
        username = getIntent().getStringExtra("username");
        password = getIntent().getStringExtra("password");

        NavController navController=Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupWithNavController(navView, navController);

    }

    public String getUsername(){
        return username;
    }
    public String getPassword() { return password;}
}
