package com.example.bottom_coffeeshop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ActivityDrink extends AppCompatActivity {

    ListView list_drink;
    ArrayList<MotaListDrinks> arrayDrink;
    MotaDrinkAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink);

        Anhxa();
        adapter = new MotaDrinkAdapter(this,R.layout.list_drinks,arrayDrink);
        list_drink.setAdapter(adapter);
        list_drink.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent(ActivityDrink.this,InforDrinks.class);
                intent.putExtra("nameDrink",arrayDrink.get(position).Name);
                intent.putExtra("priceDrink",arrayDrink.get(position).Price);
                intent.putExtra("imgDrink",arrayDrink.get(position).Image);
                startActivity(intent);
            }
        });
    }

    private void Anhxa() {
        list_drink=findViewById(R.id.list_drink);
        arrayDrink = new ArrayList<>();
        arrayDrink.add(new MotaListDrinks("Phin Sữa Đá","29.000",R.drawable.phinsuada1));
        arrayDrink.add(new MotaListDrinks("Phin Đá Đen","29.000",R.drawable.phindaden1));
        arrayDrink.add(new MotaListDrinks("Bạc Xỉu Đá","29.000",R.drawable.bacxiuda1));
        arrayDrink.add(new MotaListDrinks("Phin Sữa Nóng","29.000",R.drawable.phinsuanong1));
        arrayDrink.add(new MotaListDrinks("Expresso","35.000",R.drawable.espresso1));
        arrayDrink.add(new MotaListDrinks("Americano","35.000",R.drawable.americano1));
        arrayDrink.add(new MotaListDrinks("Cappucino","45.000",R.drawable.cappuccino1));
        arrayDrink.add(new MotaListDrinks("Latte","45.000",R.drawable.latte1));
        arrayDrink.add(new MotaListDrinks("Mocha","49.000",R.drawable.mocha1));
        arrayDrink.add(new MotaListDrinks("Caramel Macchiato","49.000",R.drawable.caramelmacchiato1));
    }
}
