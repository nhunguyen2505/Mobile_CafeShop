package com.example.bottom_coffeeshop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class MotaDrinkAdapter extends BaseAdapter {
    Context context;
    int layout;
    List<MotaListDrinks> drinksList;

    public MotaDrinkAdapter(Context context, int layout, List<MotaListDrinks> drinksList) {
        this.context = context;
        this.layout = layout;
        this.drinksList = drinksList;
    }

    @Override
    public int getCount() {
        return drinksList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        LayoutInflater inflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view=inflater.inflate(layout,null);
        TextView txtName=view.findViewById(R.id.tvName);
        TextView txtPrice=view.findViewById(R.id.tvPricelistdrink);
        ImageView img =view.findViewById(R.id.imagelistdrink);

        MotaListDrinks drinklist = drinksList.get(position);
        txtName.setText(drinklist.getName());
        txtPrice.setText(drinklist.getPrice());
        img.setImageResource(drinklist.getImage());
        return view;
    }
}
