package com.example.bottom_coffeeshop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ActiviyCake extends AppCompatActivity {

    ListView list_cake;
    ArrayList<MotaListCakes> arrayCakes;
    MotaCakeAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cake);
        Anhxa();
        adapter = new MotaCakeAdapter(this,R.layout.list_cakes,arrayCakes);
        list_cake.setAdapter(adapter);
        list_cake.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intentCake = new Intent(ActiviyCake.this,InforCakes.class);
                intentCake.putExtra("nameCake",arrayCakes.get(position).Name);
                intentCake.putExtra("priceCake",arrayCakes.get(position).Price);
                intentCake.putExtra("imgCake",arrayCakes.get(position).Image);
                startActivity(intentCake);

            }
        });
    }

    public void Anhxa() {
        list_cake=findViewById(R.id.list_cake);
        arrayCakes = new ArrayList<>();
        arrayCakes.add(new MotaListCakes("Tiramisu","19.000",R.drawable.tiramisu));
        arrayCakes.add(new MotaListCakes("Banana Cake","19.000",R.drawable.banhchuoi));
        arrayCakes.add(new MotaListCakes("Mousse","29.000",R.drawable.mousse));
        arrayCakes.add(new MotaListCakes("Chocolate Mousse","29.000",R.drawable.moussecacao));
        arrayCakes.add(new MotaListCakes("Cheese Greentea Cake","29.000",R.drawable.phomaitraxanh));
        arrayCakes.add(new MotaListCakes("Lemon Cheese Cake","29.000",R.drawable.phomaichanhday));
        arrayCakes.add(new MotaListCakes("Caramel Cheese Cake","29.000",R.drawable.caramelphomai));
        arrayCakes.add(new MotaListCakes("DHNH Cake","29.000",R.drawable.socoladhnh));
        arrayCakes.add(new MotaListCakes("Cafe Mousse","29.000",R.drawable.phomaicafe));
    }

}
