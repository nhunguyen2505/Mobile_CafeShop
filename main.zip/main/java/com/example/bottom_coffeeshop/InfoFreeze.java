package com.example.bottom_coffeeshop;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class InfoFreeze extends AppCompatActivity {
    private ImageView img;
    private TextView tvPrice,tvName,soluong;
    private RadioGroup chooseSize;
    private RadioButton S,M,L;
    private Button Themvaogio,tang,giam,thanhtoan;
    private String[] size={"(S)"};
    int image;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.thong_tin_freeze);

        img = findViewById(R.id.image);
        tvPrice = findViewById(R.id.tvPrice);
        tvName = findViewById(R.id.tvName);
        chooseSize=findViewById(R.id.size);
        S=findViewById(R.id.buttonS);
        M=findViewById(R.id.buttonM);
        L=findViewById(R.id.buttonL);
        S.setChecked(true);
        Themvaogio=findViewById(R.id.buttontvg2);
        tang=findViewById(R.id.tang);
        giam=findViewById(R.id.giam);
        soluong=findViewById(R.id.tv);
        thanhtoan=findViewById(R.id.btnthanhtoan3);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        final String price = intent.getStringExtra("price");
        image = intent.getIntExtra("image",0);

        tvName.setText(name);
        tvPrice.setText(price);
        img.setImageResource(image);
        soluong.setText("0");

        final String s= (String) tvPrice.getText();
        final String s1= (String) tvPrice.getText();
        final DecimalFormat df = new DecimalFormat("#.000");
        chooseSize.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId){
                int checkedRadio = group.getCheckedRadioButtonId();
                if(checkedRadio==R.id.buttonS){
                    tvPrice.setText(s);
                    size[0]="(S)";
                }
                else if(checkedRadio==R.id.buttonM){
                    tvPrice.setText(String.valueOf(df.format(Float.valueOf(s)+10.000)));
                    size[0]="(M)";
                }
                else{

                    tvPrice.setText(String.valueOf(df.format(Float.valueOf(s)+16.000)));
                    size[0]="(L)";
                }
            }
        });
        S.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                doOnChangedSize(buttonView,isChecked);
            }
        });
        M.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                doOnChangedSize(buttonView,isChecked);
            }
        });
        L.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                doOnChangedSize(buttonView,isChecked);

            }
        });
        Themvaogio.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                doOnClick();
            }
        });
        tang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soluong.setText(String.valueOf(Integer.valueOf((String) soluong.getText())+1));
            }
        });
        giam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Integer.valueOf((String) soluong.getText())>0) {
                    soluong.setText(String.valueOf(Integer.valueOf((String) soluong.getText()) - 1));
                }
            }
        });
        thanhtoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doOnClickThanhToan();
            }
        });
    }
    private void doOnChangedSize(CompoundButton buttonView, boolean isChecked){
        RadioButton radioButton =(RadioButton) buttonView;
        Log.i("ANDROID","RadioButton"+radioButton.getText()+" : "+isChecked);
    }
    private void doOnClick(){
        if(Integer.valueOf((String) soluong.getText()) == 0) {
            Toast.makeText(InfoFreeze.this,"Thêm vào giỏ thất bại",Toast.LENGTH_SHORT).show();
        }
        else {
            int laq=1;
            for(int i=0; i<Menu.listdanhsach.size(); i++){
                if((tvName.getText()+" "+size[0]).equals( Menu.listdanhsach.get(i).tvName) && Menu.listdanhsach.get(i).tvPrice.equals(tvPrice.getText())){
                    Toast.makeText(InfoFreeze.this,"Đã thêm",Toast.LENGTH_SHORT).show();
                    laq=0;
                    Menu.listdanhsach.get(i).tvsoluong=String.valueOf(Integer.valueOf((String) Menu.listdanhsach.get(i).tvsoluong)+Integer.valueOf((String) soluong.getText()));
                    break;
                }
            }
            if(laq==1){
                Toast.makeText(InfoFreeze.this,"Đã thêm",Toast.LENGTH_SHORT).show();
                Menu.listdanhsach.add(new MotaThanhtoan(tvName.getText()+" "+size[0], tvPrice.getText(), image,soluong.getText()));
            }
        }
    }
    private void doOnClickThanhToan(){
        if(Integer.valueOf((String) soluong.getText()) >0){
            int laq=1;
            for(int i=0; i<Menu.listdanhsach.size(); i++){
                if((tvName.getText()+" "+size[0]).equals(Menu.listdanhsach.get(i).tvName) && Menu.listdanhsach.get(i).tvPrice.equals(tvPrice.getText())){
                    laq=0;
                    Menu.listdanhsach.get(i).tvsoluong=String.valueOf(Integer.valueOf((String) Menu.listdanhsach.get(i).tvsoluong)+Integer.valueOf((String) soluong.getText()));
                    break;
                }
            }
            if(laq==1){
                Menu.listdanhsach.add(new MotaThanhtoan(tvName.getText()+" "+size[0], tvPrice.getText(), image,soluong.getText()));
            }
            Intent intent = new Intent(InfoFreeze.this, Thanhtoan.class);
            startActivity(intent);
        }
        else {
            if(Integer.valueOf((String) soluong.getText()) ==0 && Menu.listdanhsach.size() == 0) {
                Toast.makeText(InfoFreeze.this,"Thanh toán thất bại",Toast.LENGTH_SHORT).show();
            }
            if(Integer.valueOf((String) soluong.getText()) ==0 && Menu.listdanhsach.size() != 0){
                Intent intent = new Intent(InfoFreeze.this, Thanhtoan.class);
                startActivity(intent);
            }
        }
    }
}
