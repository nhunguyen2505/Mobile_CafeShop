package com.example.bottom_coffeeshop;

public class MotaListDrinks {
    String Name;
    String Price;
    int Image;
    public MotaListDrinks(String Name,String Price,int Image){
        this.Name=Name;
        this.Price=Price;
        this.Image=Image;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public int getImage() {
        return Image;
    }

    public void setImage(int image) {
        Image = image;
    }
}
