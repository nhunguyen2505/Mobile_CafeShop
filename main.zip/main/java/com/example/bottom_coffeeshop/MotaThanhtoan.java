package com.example.bottom_coffeeshop;

public class MotaThanhtoan{
    CharSequence tvName;
    CharSequence tvPrice;
    int image;
    CharSequence tvsoluong;

    public MotaThanhtoan(CharSequence tvName, CharSequence tvPrice, int image, CharSequence tvsoluong) {
        this.tvName = tvName;
        this.tvPrice = tvPrice;
        this.image = image;
        this.tvsoluong =  tvsoluong;
    }

    public CharSequence getTvName() {
        return tvName;
    }

    public void setTvName(CharSequence tvName) {
        this.tvName = tvName;
    }

    public CharSequence getTvPrice() {
        return tvPrice;
    }

    public void setTvPrice(CharSequence tvPrice) {
        this.tvPrice = tvPrice;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public CharSequence getTvsoluong() {
        return tvsoluong;
    }

    public void setTvsoluong(CharSequence tvsoluong) {
        this.tvsoluong = tvsoluong;
    }
}
