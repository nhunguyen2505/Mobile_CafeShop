package com.example.bottom_coffeeshop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ActivityTea extends AppCompatActivity {

    ListView list_tea;
    ArrayList<MotaListTea> arrayTea;
    MotaTeaAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tea);
        Anhxa();
        adapter = new MotaTeaAdapter(this,R.layout.list_tea,arrayTea);
        list_tea.setAdapter(adapter);
        list_tea.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(ActivityTea.this,InfoTea.class);
                intent.putExtra("name",arrayTea.get(position).Name);
                intent.putExtra("price",arrayTea.get(position).Price);
                intent.putExtra("img",arrayTea.get(position).Image);
                startActivity(intent);

            }
        });
    }

    public void Anhxa() {
        list_tea=findViewById(R.id.list_tea);
        arrayTea = new ArrayList<>();
        arrayTea.add(new MotaListTea("Trà Sen Vàng","39.000",R.drawable.trasenvang1));
        arrayTea.add(new MotaListTea("Trà Thạch Đào","39.000",R.drawable.trathachdao1));
        arrayTea.add(new MotaListTea("Trà Thanh Đào","39.000",R.drawable.trathanhdao1));
        arrayTea.add(new MotaListTea("Trà Thạch Vải","39.000",R.drawable.trathachvai1));;
    }

}
