package com.example.bottom_coffeeshop;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class Thanhtoan extends AppCompatActivity {
    private ListView lvdanhsach;
    ThanhtoanAdapter adapter;
    EditText ten, dc, sdt;
    ArrayList<MotaThanhtoan> arrayds;
    static TextView tongtien;
    private Button thanhtoan;
    private Dialog dialog;
    public float sum =0;

    @RequiresApi(api = Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1)
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.thanhtoan);
        lvdanhsach=findViewById(R.id.lvdanhsach);
        tongtien=findViewById(R.id.tvsotongtien);
        ten=findViewById(R.id.edtten);
        dc=findViewById(R.id.edtdiachi);
        sdt=findViewById(R.id.edtsdt);
        arrayds= (ArrayList<MotaThanhtoan>) Menu.listdanhsach;

        adapter = new ThanhtoanAdapter(this,R.layout.mota_thanhtoan,arrayds);
        lvdanhsach.setAdapter(adapter);

        ten.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() ==0) {
                    ten.setError("Bạn bắt buộc phải nhập tên");
                } else {
                    ten.setError(null);
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        dc.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() ==0) {
                    dc.setError("Bạn bắt buộc phải nhập địa chỉ");
                } else {
                    ten.setError(null);
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        sdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() ==0) {
                    sdt.setError("Bạn bắt buộc phải nhập số điện thoại");
                } else {
                    sdt.setError(null);
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        getSum();
        thanhtoan = findViewById(R.id.btnthanhtoan);
        thanhtoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAlertDialog();
            }
        });

    }
    public static void getSum() {
        float sum = 0;
        for(int i=0; i<Menu.listdanhsach.size(); i++){
            sum=sum+Float.valueOf((String) Menu.listdanhsach.get(i).tvPrice)*Float.valueOf((String) Menu.listdanhsach.get(i).tvsoluong);
        }
        if(sum == 0){
            tongtien.setText(String.valueOf(0));
        }
        else {
            final DecimalFormat df = new DecimalFormat("#.000");
            String sum1=df.format(sum);
            tongtien.setText(sum1);
        }

    }

    private void showAlertDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("DHNH Coffee");
        builder.setMessage("Are you sure you want to pay for this one?");
        builder.setCancelable(false);
        builder.setPositiveButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) { }
        });
        builder.setNegativeButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intentTks = new Intent(Thanhtoan.this, Thankyou.class);
                startActivity(intentTks);
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}
