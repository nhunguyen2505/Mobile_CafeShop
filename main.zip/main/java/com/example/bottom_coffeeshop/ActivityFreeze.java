package com.example.bottom_coffeeshop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ActivityFreeze extends AppCompatActivity {

    ListView list_freeze;
    ArrayList<MotaListFreeze> arrayFreeze;
    MotaFreezeAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freeze);

        Anhxa();
        adapter = new MotaFreezeAdapter(this,R.layout.list_freeze,arrayFreeze);
        list_freeze.setAdapter(adapter);
        list_freeze.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent(ActivityFreeze.this,InfoFreeze.class);
                intent.putExtra("name",arrayFreeze.get(position).Name);
                intent.putExtra("price",arrayFreeze.get(position).Price);
                intent.putExtra("image",arrayFreeze.get(position).Image);
                startActivity(intent);
            }
        });
    }

    private void Anhxa() {
        list_freeze=findViewById(R.id.list_freeze);
        arrayFreeze = new ArrayList<>();
        arrayFreeze.add(new MotaListFreeze("Freeze Greentea","49.000",R.drawable.greeanteafreeze1));
        arrayFreeze.add(new MotaListFreeze("Freeze Chocolate","49.000",R.drawable.chocolatefreeze1));
        arrayFreeze.add(new MotaListFreeze("Cookies & Cream","49.000",R.drawable.cookiescream1));
        arrayFreeze.add(new MotaListFreeze("Caramel Phin Freeze","49.000",R.drawable.caramelphinfreeze1));
        arrayFreeze.add(new MotaListFreeze("Classic Phin Freeze","49.000",R.drawable.classicphinfreeze1));

    }
}
